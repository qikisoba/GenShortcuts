import s from './index.module.scss'
import { useAppSelector, useAppDispatch } from '../../hook'

import { decrement, increment } from '../../store/counterSlice'

const Main = () => {
    const count = useAppSelector((state) => state.counter.value)
    const dispatch = useAppDispatch()
    return (
        <div className={s.Header}>
            <div className={s.head}>
                <button onClick={() => dispatch(increment())}>+</button>
                <button onClick={() => dispatch(decrement())}>-</button>
                <p>{count}</p>
            </div>
        </div>
    )
}
export default Main