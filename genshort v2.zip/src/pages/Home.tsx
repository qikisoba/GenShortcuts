import Header from '../components/Header'
import React from 'react'
import { Outlet } from "react-router-dom"
import axios from '../axios'
const Home = () => {
    React.useEffect(() => {
        axios.get('/posts')
    }, [])

    return (
        <>
            <Header />
            <Outlet />
        </>
    )
}
export default Home